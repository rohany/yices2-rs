/*
 * This file is part of the Yices SMT Solver.
 * Copyright (C) 2017 SRI International.
 *
 * Yices is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Yices is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Yices.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * Print a context (for debugging mostly)
 * Moved the code here to clean-up yices_reval.c
 */

#ifndef __DUMP_CONTEXT_H
#define __DUMP_CONTEXT_H

#include <stdio.h>

#include "context/context_types.h"

/*
 * Print ctx into file f
 * - the amount of details depend on the compilation mode
 * - in MODE=debug, print a lot of stuff
 */
extern void dump_context(FILE *f, context_t *ctx);

#endif /* __DUMP_CONTEXT_H */

